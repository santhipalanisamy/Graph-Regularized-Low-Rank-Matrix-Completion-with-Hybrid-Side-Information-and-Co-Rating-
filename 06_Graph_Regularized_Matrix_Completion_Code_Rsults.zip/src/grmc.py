"""Graph-regularised matrix completion (GRMC).

Model:  r_ij ~ mu + b_i + c_j + u_i^T v_j
Loss:   sum_{(i,j) in Omega} (r_ij - r_hat_ij)^2
        + lam * sum_i n_i ||u_i||^2 + lam * sum_j m_j ||v_j||^2        (ALS-WR weighting)
        + alpha * (tr(U^T L_u U) + tr(V^T L_v V))                      (graph smoothness)
        + lam_b (||b||^2 + ||c||^2) + alpha * (b^T L_u b + c^T L_v c)   (graph-smoothed biases)

Each ALS half-step is one coupled linear system in all user (item) factors:
    (blockdiag(G_i + (lam n_i + eps) I) + alpha L (x) I) vec(U) = vec(B),  G_i = V_{Omega_i}^T V_{Omega_i}
It is solved by conjugate gradients with a block-Jacobi preconditioner, the exact inverse of the
block-diagonal part. With alpha = 0 the preconditioner is the exact inverse (plain ALS-WR).
"""
import time

import numpy as np
import scipy.sparse as sp
from scipy.sparse.linalg import cg
from sklearn.neighbors import NearestNeighbors
from sklearn.utils.extmath import randomized_svd


# ----------------------------------------------------------------------------------------- graphs
def knn_graph(X, k=10):
    """Symmetric cosine k-NN graph with weights max(sim, 0), scaled to mean degree 1. Zero rows stay isolated."""
    n = X.shape[0]
    norms = np.sqrt(np.asarray(X.multiply(X).sum(1)).ravel()) if sp.issparse(X) else np.linalg.norm(X, axis=1)
    valid = np.where(norms > 0)[0]
    if len(valid) < 2:
        return sp.csr_matrix((n, n))
    Xv = X[valid]
    nn = NearestNeighbors(n_neighbors=min(k + 1, len(valid)), metric="cosine", algorithm="brute").fit(Xv)
    dist, ind = nn.kneighbors(Xv)
    rows = np.repeat(valid, ind.shape[1])
    cols = valid[ind.ravel()]
    w = np.clip(1.0 - dist.ravel(), 0.0, None)
    keep = (rows != cols) & (w > 0)
    W = sp.csr_matrix((w[keep], (rows[keep], cols[keep])), shape=(n, n))
    W = W.maximum(W.T).tocsr()
    return W / (W.sum() / n)


def rating_matrix(u, i, r, n, m):
    """Sparse user x item matrix of ratings centred by each user's mean (input for co-rating graphs)."""
    s = np.bincount(u, r, minlength=n)
    c = np.bincount(u, minlength=n)
    mean = np.divide(s, c, out=np.zeros(n), where=c > 0)
    return sp.csr_matrix((r - mean[u], (u, i)), shape=(n, m))


def laplacian(W):
    return (sp.diags(np.asarray(W.sum(1)).ravel()) - W).tocsr()


def hybrid_laplacian(W_side, W_rate, beta):
    """beta = 1: side-information graph only, beta = 0: co-rating graph only."""
    if beta >= 1:
        return laplacian(W_side)
    if beta <= 0:
        return laplacian(W_rate)
    return laplacian(beta * W_side + (1 - beta) * W_rate)


# ----------------------------------------------------------------------------------------- biases
def _bias_solve(cnt, rhs, lam_b, L, alpha):
    if L is None or alpha == 0:
        return rhs / (cnt + lam_b)
    A = sp.diags(cnt + lam_b) + alpha * L
    M = sp.diags(1.0 / (cnt + lam_b + alpha * L.diagonal()))
    x, _ = cg(A, rhs, rtol=1e-8, maxiter=500, M=M)
    return x


def fit_biases(u, i, r, n, m, lam_b, Lu=None, Li=None, alpha=0.0, iters=6):
    mu = r.mean()
    cu, ci = np.bincount(u, minlength=n).astype(float), np.bincount(i, minlength=m).astype(float)
    bu, bi = np.zeros(n), np.zeros(m)
    for _ in range(iters):
        bu = _bias_solve(cu, np.bincount(u, r - mu - bi[i], minlength=n), lam_b, Lu, alpha)
        bi = _bias_solve(ci, np.bincount(i, r - mu - bu[u], minlength=m), lam_b, Li, alpha)
    return mu, bu, bi


# ----------------------------------------------------------------------------------------- GRMC
class GRMC:
    def __init__(self, k=32, lam=0.05, alpha=0.0, Lu=None, Li=None, lam_b=5.0, epochs=15,
                 eps=1e-3, tol=1e-6, maxit=100, seed=0, precond="block", patience=5):
        self.k, self.lam, self.alpha, self.Lu, self.Li = k, lam, alpha, Lu, Li
        self.lam_b, self.epochs, self.eps, self.tol, self.maxit = lam_b, epochs, eps, tol, maxit
        self.seed, self.precond, self.patience = seed, precond, patience
        self.cg_iters = []

    # -- one ALS half-step ------------------------------------------------------------------------
    def _grams(self, R, V):
        G = np.zeros((R.shape[0], self.k, self.k))
        ip, ix = R.indptr, R.indices
        for a in range(R.shape[0]):
            if ip[a + 1] > ip[a]:
                Va = V[ix[ip[a]:ip[a + 1]]]
                G[a] = Va.T @ Va
        return G

    def solve_side(self, R, V, cnt, L, X0, record=None):
        """Solve the coupled system for one side. Returns the new factors and the CG iteration count."""
        G = self._grams(R, V)
        B = R @ V
        reg = self.lam * cnt + self.eps
        use_graph = L is not None and self.alpha > 0
        D = reg + (self.alpha * L.diagonal() if use_graph else 0.0)
        I = np.eye(self.k)
        if self.precond == "block":
            P = np.linalg.inv(G + D[:, None, None] * I)
            prec = lambda Rr: np.einsum("nkl,nl->nk", P, Rr)
        elif self.precond == "jacobi":
            dg = np.einsum("nkk->nk", G) + D[:, None]
            prec = lambda Rr: Rr / dg
        else:
            prec = lambda Rr: Rr
        if not use_graph and self.precond == "block":
            return prec(B), 1

        def A(X):
            Y = np.einsum("nkl,nl->nk", G, X) + reg[:, None] * X
            if use_graph:
                Y += self.alpha * (L @ X)
            return Y

        X = X0.copy()
        Rr = B - A(X)
        Z = prec(Rr)
        p = Z.copy()
        rz = np.sum(Rr * Z)
        bnorm = np.linalg.norm(B) + 1e-300
        it = 0
        for it in range(1, self.maxit + 1):
            Ap = A(p)
            a = rz / np.sum(p * Ap)
            X += a * p
            Rr -= a * Ap
            rel = np.linalg.norm(Rr) / bnorm
            if record is not None:
                record.append(rel)
            if rel <= self.tol:
                break
            Z = prec(Rr)
            rz_new = np.sum(Rr * Z)
            p = Z + (rz_new / rz) * p
            rz = rz_new
        return X, it

    # -- training ---------------------------------------------------------------------------------
    def fit(self, u, i, r, n, m, val=None):
        t0 = time.time()
        a_b = self.alpha if (self.Lu is not None or self.Li is not None) else 0.0
        self.mu, self.bu, self.bi = fit_biases(u, i, r, n, m, self.lam_b, self.Lu, self.Li, a_b)
        res = r - self.mu - self.bu[u] - self.bi[i]
        Ru = sp.csr_matrix((res, (u, i)), shape=(n, m))
        Ri = Ru.T.tocsr()
        cu, ci = np.diff(Ru.indptr).astype(float), np.diff(Ri.indptr).astype(float)
        rng = np.random.default_rng(self.seed)
        self.U = 0.1 * rng.standard_normal((n, self.k))
        self.V = 0.1 * rng.standard_normal((m, self.k))
        self.history = []
        best = (np.inf, None)
        for ep in range(self.epochs):
            self.U, a = self.solve_side(Ru, self.V, cu, self.Lu, self.U)
            self.V, b = self.solve_side(Ri, self.U, ci, self.Li, self.V)
            self.cg_iters.append((a, b))
            if val is not None:
                e = rmse(self.predict(val[0], val[1]), val[2])
                self.history.append(e)
                if e < best[0]:
                    best = (e, ep + 1)
                elif ep + 1 - best[1] >= self.patience:
                    break
        self.best_epoch = best[1]
        self.fit_time = time.time() - t0
        return self

    def predict(self, u, i):
        p = self.mu + self.bu[u] + self.bi[i] + np.einsum("nk,nk->n", self.U[u], self.V[i])
        return np.clip(p, 1.0, 5.0)


class BiasOnly:
    def __init__(self, lam_b=5.0):
        self.lam_b = lam_b

    def fit(self, u, i, r, n, m, val=None):
        t0 = time.time()
        self.mu, self.bu, self.bi = fit_biases(u, i, r, n, m, self.lam_b)
        self.fit_time = time.time() - t0
        return self

    def predict(self, u, i):
        return np.clip(self.mu + self.bu[u] + self.bi[i], 1.0, 5.0)


class SoftImpute:
    """Soft-Impute (Mazumder, Hastie, Tibshirani 2010) on the bias residuals, solved along a
    decreasing path of nuclear-norm shrinkage values with warm starts."""

    def __init__(self, taus, lam_b=5.0, rank=60, iters=15, seed=0):
        self.taus, self.lam_b, self.rank, self.iters, self.seed = list(taus), lam_b, rank, iters, seed

    def fit_path(self, u, i, r, n, m, evals):
        """Fit along the path. evals: dict name -> (u, i, r); returns {tau: {name: rmse}} and keeps
        the factors of every tau so that predict(tau=...) works."""
        t0 = time.time()
        self.mu, self.bu, self.bi = fit_biases(u, i, r, n, m, self.lam_b)
        res = r - self.mu - self.bu[u] - self.bi[i]
        M = np.zeros((n, m))
        M[u, i] = res
        mask = np.zeros((n, m), bool)
        mask[u, i] = True
        Z = np.zeros((n, m))
        out, self.factors = {}, {}
        for tau in sorted(self.taus, reverse=True):
            for _ in range(self.iters):
                X = np.where(mask, M, Z)
                Uq, s, Vt = randomized_svd(X, self.rank, n_iter=2, random_state=self.seed)
                s = np.maximum(s - tau, 0.0)
                Z = (Uq * s) @ Vt
            self.factors[tau] = (Uq * s, Vt, int((s > 0).sum()))
            out[tau] = {k: rmse(self._pred(Z, a, b), c) for k, (a, b, c) in evals.items()}
        self.fit_time = time.time() - t0
        return out

    def _pred(self, Z, u, i):
        return np.clip(self.mu + self.bu[u] + self.bi[i] + Z[u, i], 1.0, 5.0)

    def predict(self, u, i, tau):
        US, Vt, _ = self.factors[tau]
        return np.clip(self.mu + self.bu[u] + self.bi[i] + np.einsum("nk,kn->n", US[u], Vt[:, i]), 1.0, 5.0)


def rmse(p, y):
    return float(np.sqrt(np.mean((p - y) ** 2)))


def mae(p, y):
    return float(np.mean(np.abs(p - y)))
