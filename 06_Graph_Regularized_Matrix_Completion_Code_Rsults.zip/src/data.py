"""MovieLens loaders: ratings, official / random folds, and side-information feature matrices."""
import pathlib
import re

import numpy as np
import pandas as pd
from sklearn.model_selection import KFold

RAW = pathlib.Path(__file__).resolve().parents[1] / "data" / "raw"
AGE_CODES = [1, 18, 25, 35, 45, 50, 56]          # ML-1M age groups; ML-100K ages are mapped to the same groups


def _onehot(codes):
    codes = np.asarray(codes)
    _, inv = np.unique(codes, return_inverse=True)
    out = np.zeros((len(codes), inv.max() + 1))
    out[np.arange(len(codes)), inv] = 1.0
    return out


def _block(x):
    """Scale a feature block so that every row has unit norm (each block counts equally in cosine similarity)."""
    x = np.asarray(x, float)
    n = np.linalg.norm(x, axis=1, keepdims=True)
    n[n == 0] = 1.0
    return x / n


def _zip_region(z):
    z = str(z)
    return z[0] if z[:1].isdigit() else "other"


def _user_features(age_group, gender, occupation, zipcode):
    return np.hstack([_block(_onehot(age_group)), _block(_onehot(gender)),
                      _block(_onehot(occupation)), _block(_onehot([_zip_region(z) for z in zipcode]))])


def _item_features(genres, year):
    decade = np.where(np.isnan(year), -1, (np.nan_to_num(year) // 10) * 10)
    return np.hstack([_block(genres), _block(_onehot(decade))])


def load_ml100k():
    d = RAW / "ml-100k"
    names = ["u", "i", "r", "t"]
    users = pd.read_csv(d / "u.user", sep="|", names=["u", "age", "gender", "occ", "zip"])
    items = pd.read_csv(d / "u.item", sep="|", encoding="latin-1", header=None)
    age_group = np.searchsorted(AGE_CODES, users["age"].values, side="right") - 1
    uf = _user_features(age_group, users["gender"], users["occ"], users["zip"])
    year = pd.to_datetime(items[2], format="%d-%b-%Y", errors="coerce").dt.year.values.astype(float)
    itf = _item_features(items.iloc[:, 5:24].values.astype(float), year)
    ratings = pd.read_csv(d / "u.data", sep="\t", names=names)
    folds = []
    for k in range(1, 6):
        tr = pd.read_csv(d / f"u{k}.base", sep="\t", names=names)
        te = pd.read_csv(d / f"u{k}.test", sep="\t", names=names)
        folds.append(tuple(_arr(x) for x in (tr, te)))
    return dict(name="ML-100K", n=len(users), m=len(items), ratings=_arr(ratings),
                user_feat=uf, item_feat=itf, folds=folds, fold_type="official u1-u5")


def load_ml1m(seed=42):
    d = RAW / "ml-1m"
    users = pd.read_csv(d / "users.dat", sep="::", engine="python", names=["u", "gender", "age", "occ", "zip"])
    movies = pd.read_csv(d / "movies.dat", sep="::", engine="python", names=["i", "title", "genres"],
                         encoding="latin-1")
    ratings = pd.read_csv(d / "ratings.dat", sep="::", engine="python", names=["u", "i", "r", "t"])
    rated = np.sort(ratings["i"].unique())                       # 3,706 rated movies
    pos = {mid: k for k, mid in enumerate(rated)}
    movies = movies.set_index("i").loc[rated]
    genre_names = sorted({g for gs in movies["genres"] for g in gs.split("|")})
    genres = np.array([[g in gs.split("|") for g in genre_names] for gs in movies["genres"]], float)
    year = np.array([float(m.group(1)) if (m := re.search(r"\((\d{4})\)\s*$", t)) else np.nan
                     for t in movies["title"]])
    uf = _user_features(users["age"], users["gender"], users["occ"], users["zip"])
    itf = _item_features(genres, year)
    ratings = ratings.assign(i=ratings["i"].map(pos) + 1)        # 1-based like ML-100K, converted in _arr
    arr = _arr(ratings)
    folds = []
    for tr, te in KFold(5, shuffle=True, random_state=seed).split(arr[0]):
        folds.append((tuple(a[tr] for a in arr), tuple(a[te] for a in arr)))
    return dict(name="ML-1M", n=len(users), m=len(rated), ratings=arr,
                user_feat=uf, item_feat=itf, folds=folds, fold_type="random 5-fold (seed 42)")


def _arr(df):
    return (df["u"].values.astype(np.int64) - 1, df["i"].values.astype(np.int64) - 1,
            df["r"].values.astype(float))


LOADERS = {"ml-100k": load_ml100k, "ml-1m": load_ml1m}
