"""All experiments for graph-regularised matrix completion on MovieLens-100K and MovieLens-1M.

E1  main comparison, 5 folds per data set (hyper-parameters tuned on a validation split of fold 1)
E2  sparsity study (ML-1M): 5-100% of the training ratings
E3  cold-start users and items (ML-1M): 0-10 observed ratings for held-out users / items
E4  linear solver: CG vs Jacobi-PCG vs block-Jacobi-PCG on one ALS system (ML-1M)
E5  graph smoothness of the learned factors
"""
import json
import pathlib
import sys
import time

import numpy as np
import pandas as pd
from scipy import stats
from sklearn.utils.extmath import randomized_svd

sys.path.insert(0, str(pathlib.Path(__file__).parent))
from data import LOADERS  # noqa: E402
from grmc import (GRMC, BiasOnly, SoftImpute, hybrid_laplacian, knn_graph, laplacian, mae,  # noqa: E402
                  rating_matrix, rmse)

ROOT = pathlib.Path(__file__).resolve().parents[1]
QUICK = bool(int(__import__("os").environ.get("QUICK", "0")))
RES = ROOT / ("results_quick" if QUICK else "results")
RES.mkdir(exist_ok=True)
FIG = RES / "figures"
FIG.mkdir(parents=True, exist_ok=True)
LOG = open(RES / "run_log.txt", "a")

KNN = 10
K_GRID = [10, 20, 40]
LAM_GRID = [0.025, 0.05, 0.075, 0.1, 0.15, 0.2, 0.25]
GR_LAM_GRID = [0.025, 0.05, 0.1]
ALPHA_GRID = [1.0, 3.0, 10.0, 30.0, 100.0, 300.0]
LAMB_GRID = [1, 3, 5, 10, 25]
TAU_REL = [0.8, 0.6, 0.45, 0.33, 0.25, 0.18, 0.12, 0.08]
MAX_EPOCHS = 60
VARIANTS = {"GRMC-side": 1.0, "GRMC-rating": 0.0, "GRMC-hybrid": 0.5}
if QUICK:
    K_GRID, LAM_GRID, GR_LAM_GRID, ALPHA_GRID, LAMB_GRID, TAU_REL, MAX_EPOCHS = [10], [0.1], [0.1], [1.0], [5], [0.4, 0.25], 3
ORDER = ["Bias", "Soft-Impute", "MF (ALS-WR)", "GRMC-side", "GRMC-rating", "GRMC-hybrid"]


def log(*a):
    s = " ".join(str(x) for x in a)
    print(s, flush=True)
    LOG.write(s + "\n")
    LOG.flush()


def split(arr, frac, seed):
    rng = np.random.default_rng(seed)
    idx = rng.permutation(len(arr[0]))
    cut = int(len(idx) * (1 - frac))
    a, b = idx[:cut], idx[cut:]
    return tuple(x[a] for x in arr), tuple(x[b] for x in arr)


def graphs(d, tr):
    """Side-information graphs (fixed) and co-rating graphs (from the training ratings only)."""
    n, m = d["n"], d["m"]
    R = rating_matrix(*tr, n, m)
    return dict(Wus=d["Wus"], Wis=d["Wis"], Wur=knn_graph(R, KNN), Wir=knn_graph(R.T.tocsr(), KNN))


def laps(G, beta):
    return hybrid_laplacian(G["Wus"], G["Wur"], beta), hybrid_laplacian(G["Wis"], G["Wir"], beta)


def make_model(name, hp, G, epochs=None, seed=0):
    if name == "Bias":
        return BiasOnly(hp["lam_b"])
    p = hp[name]
    ep = epochs or p["epochs"]
    if name == "MF (ALS-WR)":
        return GRMC(k=p["k"], lam=p["lam"], lam_b=hp["lam_b"], epochs=ep, seed=seed)
    Lu, Li = laps(G, VARIANTS[name])
    return GRMC(k=p["k"], lam=p["lam"], alpha=p["alpha"], Lu=Lu, Li=Li, lam_b=hp["lam_b"], epochs=ep, seed=seed)


# ----------------------------------------------------------------------------------------- tuning
def tune(d, tr, val, G, tag, variants=tuple(VARIANTS), k_grid=K_GRID, verbose=True):
    n, m = d["n"], d["m"]
    rows, hp = [], {}
    # bias regularisation
    best = min(((rmse(BiasOnly(lb).fit(*tr, n, m).predict(val[0], val[1]), val[2]), lb) for lb in LAMB_GRID))
    hp["lam_b"] = best[1]
    rows.append(dict(model="Bias", lam_b=best[1], val_rmse=best[0]))
    # MF
    cands = []
    for k in k_grid:
        for lam in LAM_GRID:
            mdl = GRMC(k=k, lam=lam, lam_b=hp["lam_b"], epochs=MAX_EPOCHS).fit(*tr, n, m, val=val)
            e = min(mdl.history)
            cands.append((e, dict(k=k, lam=lam, epochs=mdl.best_epoch)))
            rows.append(dict(model="MF (ALS-WR)", k=k, lam=lam, epochs=mdl.best_epoch, val_rmse=e))
    hp["MF (ALS-WR)"] = min(cands, key=lambda x: x[0])[1]
    k = hp["MF (ALS-WR)"]["k"]
    # graph variants (same rank as MF)
    for name in variants:
        Lu, Li = laps(G, VARIANTS[name])
        cands = []
        for lam in GR_LAM_GRID:
            for alpha in ALPHA_GRID:
                mdl = GRMC(k=k, lam=lam, alpha=alpha, Lu=Lu, Li=Li, lam_b=hp["lam_b"],
                           epochs=MAX_EPOCHS).fit(*tr, n, m, val=val)
                e = min(mdl.history)
                cands.append((e, dict(k=k, lam=lam, alpha=alpha, epochs=mdl.best_epoch)))
                rows.append(dict(model=name, k=k, lam=lam, alpha=alpha, epochs=mdl.best_epoch, val_rmse=e))
        hp[name] = min(cands, key=lambda x: x[0])[1]
    if verbose:
        for key, v in hp.items():
            log(f"  [{tag}] {key}: {v}")
    return hp, pd.DataFrame(rows)


def tune_softimpute(d, tr, val):
    n, m = d["n"], d["m"]
    b = BiasOnly(5).fit(*tr, n, m)
    M = np.zeros((n, m))
    M[tr[0], tr[1]] = tr[2] - b.mu - b.bu[tr[0]] - b.bi[tr[1]]
    s1 = randomized_svd(M, 1, random_state=0)[1][0]
    si = SoftImpute([s1 * t for t in TAU_REL])
    out = si.fit_path(*tr, n, m, {"val": val})
    rows = [dict(model="Soft-Impute", tau_rel=tau / s1, rank=si.factors[tau][2], val_rmse=o["val"])
            for tau, o in out.items()]
    best = min(rows, key=lambda r: r["val_rmse"])
    return dict(tau_rel=best["tau_rel"]), pd.DataFrame(rows)


def fit_softimpute(d, tr, te, tau_rel, lam_b):
    n, m = d["n"], d["m"]
    b = BiasOnly(lam_b).fit(*tr, n, m)
    M = np.zeros((n, m))
    M[tr[0], tr[1]] = tr[2] - b.mu - b.bu[tr[0]] - b.bi[tr[1]]
    s1 = randomized_svd(M, 1, random_state=0)[1][0]
    taus = [s1 * t for t in TAU_REL if t >= tau_rel - 1e-12]          # warm-start path down to the chosen value
    si = SoftImpute(taus, lam_b=lam_b)
    t0 = time.time()
    si.fit_path(*tr, n, m, {})
    tau = min(taus)
    return si.predict(te[0], te[1], tau), time.time() - t0


# ----------------------------------------------------------------------------------------- E1
def activity_bins(cnt):
    return np.digitize(cnt, [30, 100])            # 0: <30, 1: 30-99, 2: >=100 training ratings


def e1_main(d):
    name = d["name"]
    log(f"\n=== E1 {name}: {d['fold_type']}")
    tr0, te0 = d["folds"][0]
    tr, val = split(tr0, 0.1, seed=0)
    G = graphs(d, tr)
    t0 = time.time()
    hp, tune_df = tune(d, tr, val, G, name)
    si_hp, si_df = tune_softimpute(d, tr, val)
    hp["Soft-Impute"] = si_hp
    log(f"  [{name}] Soft-Impute: {si_hp}  (tuning {time.time() - t0:.0f}s)")
    pd.concat([tune_df, si_df]).to_csv(RES / f"tuning_{d['key']}.csv", index=False)

    rows, bins = [], []
    for f, (tr, te) in enumerate(d["folds"]):
        G = graphs(d, tr)
        cnt = np.bincount(tr[0], minlength=d["n"])
        b_te = activity_bins(cnt[te[0]])
        for mname in ORDER:
            if mname == "Soft-Impute":
                p, ft = fit_softimpute(d, tr, te, si_hp["tau_rel"], hp["lam_b"])
            else:
                mdl = make_model(mname, hp, G).fit(*tr, d["n"], d["m"])
                p, ft = mdl.predict(te[0], te[1]), mdl.fit_time
            rows.append(dict(dataset=name, fold=f + 1, model=mname, rmse=rmse(p, te[2]), mae=mae(p, te[2]),
                             fit_time_s=ft))
            for bb in range(3):
                s = b_te == bb
                bins.append(dict(dataset=name, fold=f + 1, model=mname, bin=["<30", "30-99", ">=100"][bb],
                                 n_test=int(s.sum()), rmse=rmse(p[s], te[2][s])))
        log(f"  fold {f + 1}: " + "  ".join(f"{r['model']}={r['rmse']:.4f}" for r in rows[-len(ORDER):]))
    df = pd.DataFrame(rows)
    return hp, df, pd.DataFrame(bins)


# ----------------------------------------------------------------------------------------- E2
def e2_sparsity(d, hp_full):
    log("\n=== E2 sparsity (ML-1M, fold 1)")
    tr_full, te = d["folds"][0]
    rows = []
    for frac in [0.05, 0.1, 0.25, 0.5, 1.0]:
        # tune on seed 0 of this fraction
        sub, _ = split(tr_full, 1 - frac, seed=100) if frac < 1 else (tr_full, None)
        tr, val = split(sub, 0.1, seed=0)
        G = graphs(d, tr)
        if frac < 1:
            hp, _ = tune(d, tr, val, G, f"{frac:.0%}", k_grid=[hp_full["MF (ALS-WR)"]["k"]], verbose=False)
        else:
            hp = hp_full
        log(f"  {frac:.0%}: " + ", ".join(f"{k}: lam={v['lam']}" + (f" a={v['alpha']}" if "alpha" in v else "")
                                          for k, v in hp.items() if isinstance(v, dict) and "lam" in v))
        for seed in range(3):
            sub, _ = split(tr_full, 1 - frac, seed=100 + seed) if frac < 1 else (tr_full, None)
            G = graphs(d, sub)
            for mname in ["Bias", "MF (ALS-WR)", *VARIANTS]:
                mdl = make_model(mname, hp, G, seed=seed).fit(*sub, d["n"], d["m"])
                p = mdl.predict(te[0], te[1])
                rows.append(dict(train_fraction=frac, n_train=len(sub[0]), seed=seed, model=mname,
                                 rmse=rmse(p, te[2]), mae=mae(p, te[2])))
        g = pd.DataFrame(rows).query("train_fraction == @frac").groupby("model")["rmse"].mean()
        log("     " + "  ".join(f"{k}={v:.4f}" for k, v in g.items()))
    return pd.DataFrame(rows)


# ----------------------------------------------------------------------------------------- E3
def e3_coldstart(d, hp):
    log("\n=== E3 cold start (ML-1M)")
    u, i, r = d["ratings"]
    n, m = d["n"], d["m"]
    rows = []
    for side in ["user", "item"]:
        ent = u if side == "user" else i
        cnt = np.bincount(ent, minlength=n if side == "user" else m)
        for seed in range(3):
            rng = np.random.default_rng(1000 + seed)
            eligible = np.where(cnt >= 30)[0]
            cold = rng.choice(eligible, size=int(0.2 * len(eligible)), replace=False)
            is_cold = np.isin(ent, cold)
            order = rng.permutation(len(u))                         # random order of each cold entity's ratings
            rank_in = np.empty(len(u), int)
            ent_sorted = ent[order]
            o2 = np.argsort(ent_sorted, kind="stable")
            pos = np.empty(len(u), int)
            starts = np.r_[0, np.cumsum(np.bincount(ent_sorted, minlength=len(cnt)))[:-1]]
            pos[o2] = np.arange(len(u)) - starts[ent_sorted[o2]]
            rank_in[order] = pos
            for k_obs in [0, 1, 2, 5, 10]:
                tr_mask = ~is_cold | (rank_in < k_obs)
                te_mask = is_cold & (rank_in >= 10)                 # same test ratings for every k_obs
                tr = (u[tr_mask], i[tr_mask], r[tr_mask])
                te = (u[te_mask], i[te_mask], r[te_mask])
                G = graphs(d, tr)
                for mname in ["Bias", "MF (ALS-WR)", *VARIANTS]:
                    mdl = make_model(mname, hp, G, seed=seed).fit(*tr, n, m)
                    p = mdl.predict(te[0], te[1])
                    rows.append(dict(side=side, seed=seed, k_observed=k_obs, model=mname, n_cold=len(cold),
                                     n_test=len(te[0]), rmse=rmse(p, te[2]), mae=mae(p, te[2])))
            log(f"  {side} seed {seed} done")
        g = pd.DataFrame(rows).query("side == @side").groupby(["k_observed", "model"])["rmse"].mean().unstack()
        log(g.round(4).to_string())
    return pd.DataFrame(rows)


# ----------------------------------------------------------------------------------------- E4, E5
def e4_solver(d, hp):
    log("\n=== E4 linear solver (ML-1M, fold 1, user system, GRMC-hybrid)")
    tr, _ = d["folds"][0]
    n, m = d["n"], d["m"]
    G = graphs(d, tr)
    p = hp["GRMC-hybrid"]
    Lu, Li = laps(G, VARIANTS["GRMC-hybrid"])
    base = GRMC(k=p["k"], lam=p["lam"], alpha=p["alpha"], Lu=Lu, Li=Li, lam_b=hp["lam_b"], epochs=5).fit(*tr, n, m)
    res = tr[2] - base.mu - base.bu[tr[0]] - base.bi[tr[1]]
    import scipy.sparse as sp
    Ru = sp.csr_matrix((res, (tr[0], tr[1])), shape=(n, m))
    cu = np.diff(Ru.indptr).astype(float)
    rows, summ = [], []
    for alpha in [p["alpha"], 10 * p["alpha"]]:
        for pc in ["none", "jacobi", "block"]:
            s = GRMC(k=p["k"], lam=p["lam"], alpha=alpha, lam_b=hp["lam_b"], tol=1e-10, maxit=500, precond=pc)
            rec = []
            t0 = time.time()
            s.solve_side(Ru, base.V, cu, Lu, np.zeros((n, p["k"])), record=rec)
            dt = time.time() - t0
            rows += [dict(alpha=alpha, preconditioner=pc, iteration=j + 1, rel_residual=x) for j, x in enumerate(rec)]
            it6 = next((j + 1 for j, x in enumerate(rec) if x <= 1e-6), None)
            summ.append(dict(alpha=alpha, preconditioner=pc, iters_to_1e6=it6, iters_to_1e10=len(rec),
                             time_s=round(dt, 3)))
            log(f"  alpha={alpha:g} {pc:7s}: iters to 1e-6 = {it6}, to 1e-10 = {len(rec)}, {dt:.2f}s")
    return pd.DataFrame(rows), pd.DataFrame(summ)


def dirichlet_ratio(L, X):
    """tr(X^T L X) / tr(X^T X), normalised by the same quantity for a random row permutation of X."""
    rng = np.random.default_rng(0)
    e = np.sum(X * (L @ X)) / np.sum(X * X)
    Xp = X[rng.permutation(len(X))]
    return e / (np.sum(Xp * (L @ Xp)) / np.sum(Xp * Xp))


def e5_smoothness(d, hp):
    log("\n=== E5 smoothness of learned factors (ML-1M, fold 1)")
    tr, _ = d["folds"][0]
    G = graphs(d, tr)
    Ls_u, Ls_i = laplacian(G["Wus"]), laplacian(G["Wis"])
    Lr_u, Lr_i = laplacian(G["Wur"]), laplacian(G["Wir"])
    rows = []
    for mname in ["MF (ALS-WR)", *VARIANTS]:
        mdl = make_model(mname, hp, G).fit(*tr, d["n"], d["m"])
        rows.append(dict(model=mname, user_side=dirichlet_ratio(Ls_u, mdl.U), user_rating=dirichlet_ratio(Lr_u, mdl.U),
                         item_side=dirichlet_ratio(Ls_i, mdl.V), item_rating=dirichlet_ratio(Lr_i, mdl.V),
                         mean_cg_iters=float(np.mean(mdl.cg_iters))))
        log("  " + "  ".join(f"{k}={v:.3f}" if isinstance(v, float) else str(v) for k, v in rows[-1].items()))
    return pd.DataFrame(rows)


# ----------------------------------------------------------------------------------------- figures
def figures(main_sum, sp_df, cs_df, solver_df, tune_dfs, bins_df):
    import matplotlib
    matplotlib.use("Agg")
    import matplotlib.pyplot as plt
    plt.rcParams.update({"font.size": 9, "axes.spines.top": False, "axes.spines.right": False})
    col = {"Bias": "#9e9e9e", "MF (ALS-WR)": "#1f77b4", "GRMC-side": "#2ca02c", "GRMC-rating": "#ff7f0e",
           "GRMC-hybrid": "#d62728", "Soft-Impute": "#8c564b"}

    # fig1 sparsity
    fig, ax = plt.subplots(figsize=(4.6, 3.0))
    g = sp_df.groupby(["train_fraction", "model"])["rmse"].agg(["mean", "std"]).reset_index()
    for mname in ["Bias", "MF (ALS-WR)", *VARIANTS]:
        s = g[g.model == mname]
        ax.errorbar(s.train_fraction * 100, s["mean"], yerr=s["std"], marker="o", ms=3, lw=1.3, capsize=2,
                    label=mname, color=col[mname])
    ax.set_xscale("log")
    ax.set_xticks([5, 10, 25, 50, 100])
    ax.set_xticklabels(["5", "10", "25", "50", "100"])
    ax.set_xlabel("training ratings used (%)")
    ax.set_ylabel("test RMSE")
    ax.legend(frameon=False, fontsize=7)
    fig.tight_layout()
    fig.savefig(FIG / "fig1_sparsity.png", dpi=200)
    plt.close(fig)

    # fig2 cold start
    fig, axes = plt.subplots(1, 2, figsize=(7.2, 2.8), sharey=False)
    for ax, side in zip(axes, ["user", "item"]):
        g = cs_df[cs_df.side == side].groupby(["k_observed", "model"])["rmse"].agg(["mean", "std"]).reset_index()
        for mname in ["Bias", "MF (ALS-WR)", *VARIANTS]:
            s = g[g.model == mname]
            ax.errorbar(s.k_observed, s["mean"], yerr=s["std"], marker="o", ms=3, lw=1.3, capsize=2,
                        label=mname, color=col[mname])
        ax.set_title(f"cold-start {side}s")
        ax.set_xlabel(f"observed ratings per cold {side}")
        ax.set_ylabel("test RMSE")
    axes[0].legend(frameon=False, fontsize=7)
    fig.tight_layout()
    fig.savefig(FIG / "fig2_coldstart.png", dpi=200)
    plt.close(fig)

    # fig3 alpha sensitivity (validation RMSE at the selected lambda of each variant)
    fig, axes = plt.subplots(1, 2, figsize=(7.2, 2.6))
    for ax, (key, (tdf, hp)) in zip(axes, tune_dfs.items()):
        for mname in VARIANTS:
            s = tdf[(tdf.model == mname) & (tdf.lam == hp[mname]["lam"])].sort_values("alpha")
            ax.plot(s.alpha, s.val_rmse, marker="o", ms=3, lw=1.3, label=mname, color=col[mname])
        mf = hp["MF (ALS-WR)"]
        v = tdf[(tdf.model == "MF (ALS-WR)") & (tdf.k == mf["k"]) & (tdf.lam == mf["lam"])].val_rmse.iloc[0]
        ax.axhline(v, color=col["MF (ALS-WR)"], ls="--", lw=1, label="MF (ALS-WR)")
        ax.set_xscale("log")
        ax.set_xlabel(r"graph weight $\alpha$")
        ax.set_ylabel("validation RMSE")
        ax.set_title(key)
    axes[0].legend(frameon=False, fontsize=7)
    fig.tight_layout()
    fig.savefig(FIG / "fig3_alpha_sensitivity.png", dpi=200)
    plt.close(fig)

    # fig4 solver
    fig, axes = plt.subplots(1, 2, figsize=(7.2, 2.6), sharey=True)
    for ax, alpha in zip(axes, sorted(solver_df.alpha.unique())):
        for pc, c in [("none", "#7f7f7f"), ("jacobi", "#1f77b4"), ("block", "#d62728")]:
            s = solver_df[(solver_df.alpha == alpha) & (solver_df.preconditioner == pc)]
            ax.semilogy(s.iteration, s.rel_residual, lw=1.3, color=c,
                        label={"none": "CG", "jacobi": "Jacobi-PCG", "block": "block-Jacobi PCG"}[pc])
        ax.set_title(rf"$\alpha$ = {alpha:g}")
        ax.set_xlabel("iteration")
    axes[0].set_ylabel("relative residual")
    axes[0].legend(frameon=False, fontsize=7)
    fig.tight_layout()
    fig.savefig(FIG / "fig4_solver_convergence.png", dpi=200)
    plt.close(fig)

    # fig5 activity bins
    fig, axes = plt.subplots(1, 2, figsize=(7.2, 2.6))
    models = ["MF (ALS-WR)", *VARIANTS]
    for ax, ds in zip(axes, bins_df.dataset.unique()):
        g = bins_df[bins_df.dataset == ds].groupby(["bin", "model"])["rmse"].mean().unstack()
        g = g.loc[["<30", "30-99", ">=100"], models]
        x = np.arange(3)
        for j, mname in enumerate(models):
            ax.bar(x + (j - 1.5) * 0.2, g[mname], width=0.2, color=col[mname], label=mname)
        ax.set_xticks(x)
        ax.set_xticklabels(["<30", "30-99", "≥100"])
        ax.set_xlabel("training ratings of the user")
        ax.set_ylabel("test RMSE")
        ax.set_ylim(g.values.min() - 0.03, g.values.max() + 0.02)
        ax.set_title(ds)
    axes[0].legend(frameon=False, fontsize=7)
    fig.tight_layout()
    fig.savefig(FIG / "fig5_activity_bins.png", dpi=200)
    plt.close(fig)


# ----------------------------------------------------------------------------------------- main
def main():
    t_start = time.time()
    info = {}
    data = {}
    for key in ["ml-100k", "ml-1m"]:
        d = LOADERS[key]()
        d["key"] = key
        d["Wus"], d["Wis"] = knn_graph(d["user_feat"], KNN), knn_graph(d["item_feat"], KNN)
        data[key] = d
        log(f"{d['name']}: {d['n']} users, {d['m']} items, {len(d['ratings'][0])} ratings, "
            f"density {len(d['ratings'][0]) / (d['n'] * d['m']):.4f}; user features {d['user_feat'].shape[1]}, "
            f"item features {d['item_feat'].shape[1]}")
        info[d["name"]] = dict(users=d["n"], items=d["m"], ratings=len(d["ratings"][0]),
                               density=len(d["ratings"][0]) / (d["n"] * d["m"]), folds=d["fold_type"],
                               side_graph_edges_user=int(d["Wus"].nnz // 2), side_graph_edges_item=int(d["Wis"].nnz // 2))

    hps, per_fold, bins, tune_dfs = {}, [], [], {}
    resume = (RES / "hyperparameters.json").exists() and (RES / "main_results_per_fold.csv").exists()
    if resume:                       # E1 already done: reuse its hyper-parameters and per-fold results
        log("Resuming: E1 results and hyper-parameters loaded from results/")
        hps = json.load(open(RES / "hyperparameters.json"))
        per_fold = pd.read_csv(RES / "main_results_per_fold.csv")
        bins = pd.read_csv(RES / "rmse_by_user_activity.csv")
        for key, d in data.items():
            tune_dfs[d["name"]] = (pd.read_csv(RES / f"tuning_{key}.csv"), hps[d["name"]])
    else:
        for key, d in data.items():
            hp, df, b = e1_main(d)
            hps[d["name"]] = hp
            per_fold.append(df)
            bins.append(b)
            tune_dfs[d["name"]] = (pd.read_csv(RES / f"tuning_{key}.csv"), hp)
        per_fold = pd.concat(per_fold)
        bins = pd.concat(bins)
        json.dump(hps, open(RES / "hyperparameters.json", "w"), indent=2, default=float)
    per_fold.to_csv(RES / "main_results_per_fold.csv", index=False)
    bins.to_csv(RES / "rmse_by_user_activity.csv", index=False)
    summ = per_fold.groupby(["dataset", "model"], sort=False).agg(
        rmse_mean=("rmse", "mean"), rmse_std=("rmse", "std"), mae_mean=("mae", "mean"), mae_std=("mae", "std"),
        fit_time_s=("fit_time_s", "mean")).reset_index()
    tests = []
    for ds in per_fold.dataset.unique():
        base = per_fold[(per_fold.dataset == ds) & (per_fold.model == "MF (ALS-WR)")].sort_values("fold").rmse.values
        for mname in ORDER:
            if mname == "MF (ALS-WR)":
                continue
            x = per_fold[(per_fold.dataset == ds) & (per_fold.model == mname)].sort_values("fold").rmse.values
            t = stats.ttest_rel(x, base)
            tests.append(dict(dataset=ds, model=mname, delta_rmse_vs_MF=float(np.mean(x - base)),
                              folds_better=int(np.sum(x < base)), t=float(t.statistic), p=float(t.pvalue)))
    pd.DataFrame(tests).to_csv(RES / "paired_tests_vs_MF.csv", index=False)
    summ.to_csv(RES / "main_results_summary.csv", index=False)
    log("\n" + summ.round(4).to_string(index=False))
    log("\n" + pd.DataFrame(tests).round(5).to_string(index=False))

    d = data["ml-1m"]
    hp1m = hps["ML-1M"]
    sp_df = e2_sparsity(d, hp1m)
    sp_df.to_csv(RES / "sparsity_ml1m.csv", index=False)
    cs_df = e3_coldstart(d, hp1m)
    cs_df.to_csv(RES / "coldstart_ml1m.csv", index=False)
    solver_df, solver_sum = e4_solver(d, hp1m)
    solver_df.to_csv(RES / "solver_convergence.csv", index=False)
    solver_sum.to_csv(RES / "solver_summary.csv", index=False)
    sm = e5_smoothness(d, hp1m)
    sm.to_csv(RES / "factor_smoothness.csv", index=False)

    figures(summ, sp_df, cs_df, solver_df, tune_dfs, bins)
    info["hyperparameters"] = hps
    info["knn"] = KNN
    info["runtime_min"] = round((time.time() - t_start) / 60, 1)
    json.dump(info, open(RES / "run_info.json", "w"), indent=2, default=float)
    log(f"\nTotal runtime {info['runtime_min']} min")


if __name__ == "__main__":
    main()
